____________________________________________________________________________________________
3DTRAINS ADDON FOR MICROSOFT TRAIN SIMULATOR
Smoke Image Replacement v1.1
File Date: 12.08.05
____________________________________________________________________________________________
INSTALLATION & FILE NOTES

Make a backup of the SMOKEMAIN.ACE file (copy to a temporary folder in the event you wish to
use the old texture), located in the Train Simulator\Global\Textures folder.

Start the self-installer by double-left-clicking, and when prompted, browse to the Train
Simulator folder on your PC. MSTS is typically installed to the following directory:

	C:\Program Files\Microsoft Games\Train Simulator

If this matches your installation of MSTS, then you don't need to browse or go looking for
the MSTS folder. Just accept the prompts in the self-installer, and once finished, simply
start MSTS and check out the new smoke effects on your favorite steamer. :)

If you have any issues with the enclosed files, please post a note on the 3DTrains forums:

	http://www.3dtrains.com/forums/index.php

Or you can email me: mnelson@3dtrains.com

Cheers!
Marc - 3DTrains.com
____________________________________________________________________________________________
VERSION HISTORY

v1.2		12.08.05:
 - Retextured smoke

v1.1		12.06.05:
 - Added noise filter
 - Adjusted alpha channel

v1.0		12.05.05:
 - Initial release

v1.0 Beta	12.04.05:
 - Beta testing
____________________________________________________________________________________________
v1.0
