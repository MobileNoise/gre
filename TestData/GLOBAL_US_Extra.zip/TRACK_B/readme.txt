Dodatek do MS Train Simulator 
- nowe wersje rozjazd�w z grupy "A1tScissorPnt10..."


W nowej wersji Xtracks (3.18) pojawi�o si� wiele rozjazd�w w "nowych" wersjach, jednak pomini�to te wspomniane wy�ej, a u�ywane na kilku trasach.
Pakiet zawiera r�wnie� wersje uj�te w czeskim dodatku  "UZK" ("_D" w nazwach plik�w) oraz dodatkowe rozszerzenia wersji uj�te w specjalnym podzbiorze "Track_B" (stworzonym w TS-Studio g��wnie na potrzeby projektu "Breclav-Praha" by Zbynek Semora)

Instalacja: 
1. Folder "Global" wypakowa� to katalogu g��wnego zainstalowanego msts-a.
2. Opcjonalnie - dla u�ytkownik�w tras czeskich: w podobny spos�b wypakowa� 
folder "Track_B"

Gotowe   


===============================================
(C) TS-Studio  1/2007 
===============================================
LICENCJA
 - ograniczone "freeware"
1. modele 3D nie mog� by� wykorzystane w celach komercyjnych
2. rozpowszechnianie w innych serwisach World Wide Web bez zgody autora (autor�w) zabronione.
3. Wykorzystanie i redystrybucja w innym celu lub w inny spos�b bez zgody autora (autor�w) zabronione.
=====================================================